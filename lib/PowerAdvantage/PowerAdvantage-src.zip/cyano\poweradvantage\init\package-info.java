/**
This package contains registries for all of the new content added by PowerAdvantage. Use these 
classes to interact with the items and blocks.
*/
package cyano.poweradvantage.init;