/**
<p>
This package contains helper classes.
</p>
*/
package cyano.poweradvantage.math;